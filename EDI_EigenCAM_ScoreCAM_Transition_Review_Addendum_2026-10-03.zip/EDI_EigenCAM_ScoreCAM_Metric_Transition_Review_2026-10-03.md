# Eigen-CAM / Score-CAM metric transition review — October 3, 2026

Reviewed edi_eigen_score_metric_transition_v1_20261004T002758_639058Z_compact_bundle.zip. Completed; 192 hash-guarded original progress files, 491 source files considered, 69 candidate sources, zero read errors. Recovered source was not executed.

## Confirmed legacy values

Each method has 3,840 original rows, 2,880 missing/nonfinite SSIM values, zero nonfinite EDI values, and exactly 2,880 EDI values equal to 1 - (Pearson correlation + 1)/2 within 1e-10. These are the r128/r160/r192 records identified in the preceding lineage audit. Thus legacy EDI omitted the unavailable structural component rather than applying the complete primary two-component formula. The 960 r224 complete triples remain equal to frozen values. All original Pearson values match frozen records. Original row tables are retained in the uploaded bundle.

## Candidate transformation source

Untitled38.ipynb, SHA256 4a97849c42c5f3cfe59f7c5d06f59d2abf2be409c1bf8a7941fdd186fd5a99d2, zero-based cell 24 defines repair_missing_ssim_for_method and its adaptive SSIM metric helper. It reads method-folder baseline and experiment arrays, normalizes/resizes them, selects SSIM windows 7/5/3 (or an 8×8 fallback), recomputes correlation, SSIM, drifts and two-component EDI, and writes method_REPAIRED.csv. This code is the previously recovered adaptive protocol; it must not be treated as a newly proven original execution.

Cells 25 and 26 call that routine for Score-CAM and Eigen-CAM. BOTH retained outputs report Missing SSIM before: 0, Repaired: 0, Missing SSIM after: 0. Earlier repair attempts in cells 11 and 19 also report Repaired: 0. Baseline-generation cells in this saved copy likewise do not establish fresh baseline generation for this transition. The saved invocation therefore copies already-complete data; it does not demonstrate the historical 2,880-row transformation. Candidate code existence is not execution provenance.

Untitled37.ipynb reads the repaired standalone files and retains a complete four-method P3 aggregate with no missing SSIM. This supports downstream consumption of already repaired data, not the identity of the original repair run.

## Status and action

Established: original progress metrics, correlation-only legacy formula, complete later export values, adaptive candidate repair implementation. Unresolved: the specific historical repair invocation, exact baseline array identity, and complete map-to-frozen-metric reproduction. The existing adaptive/current-map audits must remain separately described; do not rerun them just because this candidate source was recovered.

Preserve both legacy and later data versions. Do not overwrite canonical dissertation values or describe all four remaining methods as fully reproduced. Record the historical transition as an unresolved provenance limitation. The next useful task is consolidating the method-by-method provenance status and preparing precise Chapter 3/Chapter 5 copy-paste qualifications. Additional source recovery should depend on genuinely new historical notebook versions, archived arrays, or original hashes, rather than more searches of the same saved sources.

Add this review and original bundle as a repository checkpoint addendum. It supersedes the preceding hypothesis that lower-resolution SSIM was merely unavailable for comparison: original missing values and correlation-only EDI are now directly verified.
