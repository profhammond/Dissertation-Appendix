import zipfile,io,json,hashlib,sys
from pathlib import Path
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parent
src=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT.parent/'training_variability/CH05_Matched_Initialization_Provenance_Audit_v2.zip'
with zipfile.ZipFile(src) as z:
 raw=z.read(next(n for n in z.namelist() if n.endswith('.parquet')));d=pd.read_parquet(io.BytesIO(raw))
 with zipfile.ZipFile(io.BytesIO(z.read(next(n for n in z.namelist() if '/inputs/' in n and n.endswith('.zip'))))) as dz:
  diag=pd.DataFrame([json.loads(dz.read(n)) for n in dz.namelist() if n.endswith('.json')])
assert len(d)==2160 and not d.duplicated(['pair_id','attribution_method','image_id']).any()
for side in ['a','b']:
 q=diag[['condition','seed','method','image_id','used_signed_fallback']].rename(columns={'condition':'condition_'+side,'seed':'seed_'+side,'method':'attribution_method','used_signed_fallback':'fallback_'+side})
 d=d.merge(q,on=['condition_'+side,'seed_'+side,'attribution_method','image_id'],validate='many_to_one')
 assert d['fallback_'+side].notna().all()
d['fallback_involved']=d.fallback_a|d.fallback_b
d.to_csv(ROOT/'comparison_records_with_fallback.csv',index=False)
B=5000;SEED=20261005;rng=np.random.default_rng(SEED);out=[]
for sensitivity in ['all_records','exclude_signed_fallback']:
 dd=d if sensitivity=='all_records' else d[~d.fallback_involved]
 for method in ['gradcam','gradcampp']:
  ref=dd[(dd.comparison_type=='within_condition_cross_seed')&(dd.condition_a=='baseline')&(dd.attribution_method==method)]
  for cond in ['dullrazor','telea']:
   exp=dd[(dd.comparison_type=='baseline_preprocess_matched_seed')&(dd.condition_b==cond)&(dd.attribution_method==method)]
   # All-record estimates give equal weight to images and their three pairs.
   # Exclusion sensitivity uses available pair means on common supported images.
   x=exp.groupby('image_id').edi_primary.mean();y=ref.groupby('image_id').edi_primary.mean()
   ids=sorted(set(x.index)&set(y.index));x=x.reindex(ids).to_numpy();y=y.reindex(ids).to_numpy()
   draws=rng.integers(0,len(ids),size=(B,len(ids)));v=(x-y)[draws].mean(axis=1)
   out.append(dict(sensitivity=sensitivity,method=method,condition=cond,n_images=len(ids),preprocessing_records=int(exp.image_id.isin(ids).sum()),reference_records=int(ref.image_id.isin(ids).sum()),preprocessing_mean=x.mean(),reference_mean=y.mean(),difference=(x-y).mean(),ci_low=np.quantile(v,.025),ci_high=np.quantile(v,.975)))
r=pd.DataFrame(out);r.to_csv(ROOT/'image_clustered_contrasts.csv',index=False)
(ROOT/'metadata.json').write_text(json.dumps({'source_zip_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'comparison_parquet_sha256':hashlib.sha256(raw).hexdigest(),'bootstrap_reps':B,'seed':SEED,'estimand':'mean across common images of within-image mean matched-preprocessing EDI minus within-image mean baseline cross-seed EDI','bootstrap':'paired image clusters; no label stratification (labels absent); fixed model pairs','fallback_sensitivity':'exclude affected comparisons, then available-pair means on common supported images; changed estimand and selected image support','scope':'exploratory unadjusted intervals conditional on fitted models; no population training-seed inference; saved records, no map-to-metric reproduction'},indent=2))
print(r.to_string(index=False))
