# Matched-initialization EDI uncertainty analysis v1

Exploratory analysis of the verified saved 2,160-row pilot and 720 endpoint diagnostic records. No retraining, fresh inference, attribution generation, or source changes. All-record contrasts reproduce the existing descriptive means.

Paired image-cluster bootstrap (5,000 replications, seed 20261005) estimates differences between each image's mean matched-seed preprocessing EDI and mean baseline cross-seed EDI. Forty images and the evaluated models are fixed study support. These intervals do not quantify uncertainty over a population of training seeds. Labels are absent from this input, so the bootstrap is not label-stratified.

Grad-CAM: DullRazor difference 0.158935, 95% CI [0.107157,0.216113]; Telea 0.165720 [0.110803,0.224041]. Grad-CAM++: DullRazor -0.045635 [-0.098534,0.008930]; Telea 0.006102 [-0.039466,0.052137]. These are unadjusted exploratory intervals, not multiplicity-adjusted confirmatory tests or causal fractions.

Fallback exclusion retains 31 common supported images for Grad-CAM and 39 for Grad-CAM++. Available-pair means change the sensitivity estimand and can alter image/pair support. Grad-CAM positive contrasts remain; Grad-CAM++ intervals continue to include zero. This is robustness to the specific exclusion rule, not proof of unbiased estimates or a superior attribution method.

Source-map reproduction and current generating-model identity are outside this saved-record analysis. The factorial model set audited separately must not be substituted for this later matched-initialization pilot. Existing initialization digests were checked from completion records, not recomputed from original initial arrays.

Reproduce with Python, numpy, pandas, pyarrow: python analyze.py /path/to/CH05_Matched_Initialization_Provenance_Audit_v2.zip
