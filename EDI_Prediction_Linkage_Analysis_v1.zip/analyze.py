from pathlib import Path
import zipfile,io,json,hashlib,sys
import numpy as np
import pandas as pd
from scipy.stats import rankdata
ROOT=Path(__file__).resolve().parent
SOURCE=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'upload/edi_model_input_factorial_counterfactual_ham_r224_v1_outputs (2).zip'
B=5000; SEED=20261004
with zipfile.ZipFile(SOURCE) as z:
 p=pd.read_csv(io.BytesIO(z.read('factorial_cohort_predictions.csv')))
 plan=pd.read_csv(io.BytesIO(z.read('pair_plan.csv')))
 d=pd.concat([pd.read_csv(io.BytesIO(z.read(n)),compression='gzip') for n in sorted(z.namelist()) if n.startswith('pair_parts/') and n.endswith('.csv.gz')],ignore_index=True)
assert len(d)==2400 and len(p)==960
assert not p.duplicated(['condition','seed','cell','image_id']).any()
assert not d.duplicated(['pair_id','image_id','attribution_method']).any()
assert d[['pair_id','condition','seed','comparison','cell_a','cell_b']].drop_duplicates().merge(plan,how='outer',indicator=True)._merge.eq('both').all()
for side in ['a','b']:
 q=p.rename(columns={'cell':'cell_'+side,**{c:c+'_'+side for c in ['label','probability','prediction','model_condition','input_condition']}})
 d=d.merge(q,on=['condition','seed','cell_'+side,'image_id'],how='left',validate='many_to_one')
 assert d['probability_'+side].notna().all()
assert d.label_a.eq(d.label_b).all()
d['absolute_probability_change']=(d.probability_b-d.probability_a).abs()
d['class_switch']=d.prediction_a.ne(d.prediction_b).astype(int)
d['correct_a']=d.prediction_a.eq(d.label_a)
d['correct_b']=d.prediction_b.eq(d.label_b)
d['correct_to_incorrect']=(d.correct_a&~d.correct_b).astype(int)
d['incorrect_to_correct']=(~d.correct_a&d.correct_b).astype(int)
d['transition']=np.select([d.correct_to_incorrect.eq(1),d.incorrect_to_correct.eq(1),d.correct_a&d.correct_b],['correct_to_incorrect','incorrect_to_correct','both_correct'],default='both_incorrect')
d.to_csv(ROOT/'linked_comparisons.csv',index=False)
images=sorted(d.image_id.unique()); imap={v:i for i,v in enumerate(images)}
labels=p.drop_duplicates('image_id').set_index('image_id').label.reindex(images).to_numpy()
rng=np.random.default_rng(SEED)
# One shared stratified cluster schedule for all analyses; seeds remain fixed.
ix=np.concatenate([rng.choice(np.flatnonzero(labels==l),size=(B,(labels==l).sum()),replace=True) for l in [0,1]],axis=1)
def corr(x,y):
 x=rankdata(x,axis=-1);y=rankdata(y,axis=-1)
 x=x-x.mean(axis=-1,keepdims=True);y=y-y.mean(axis=-1,keepdims=True)
 den=np.sqrt((x*x).sum(axis=-1)*(y*y).sum(axis=-1))
 return np.divide((x*y).sum(axis=-1),den,out=np.full_like(den,np.nan,dtype=float),where=den>0)
def ci(v):
 v=np.asarray(v);v=v[np.isfinite(v)]
 return (*np.quantile(v,[.025,.975]),len(v)) if len(v) else (np.nan,np.nan,0)
rows=[];events=[]
for sensitivity in ['all_records','exclude_signed_fallback']:
 dd=d if sensitivity=='all_records' else d[~d.fallback_involved]
 for key,g in dd.groupby(['condition','comparison','attribution_method'],sort=True):
  g=g.sort_values(['image_id','seed']); cluster=np.array([imap[x] for x in g.image_id])
  # Ragged records after fallback exclusion; bootstrap weights replicate complete image clusters.
  counts=np.stack([(ix==i).sum(axis=1) for i in range(40)],axis=1)
  x=g.edi_primary.to_numpy();y=g.absolute_probability_change.to_numpy()
  boot=[]
  for weights in counts:
   take=np.repeat(np.arange(len(g)),weights[cluster])
   boot.append(corr(x[take],y[take]) if len(take)>1 else np.nan)
  lo,hi,valid=ci(boot)
  rows.append(dict(sensitivity=sensitivity,condition=key[0],comparison=key[1],method=key[2],n_records=len(g),n_images=g.image_id.nunique(),spearman=float(corr(x,y)),ci_low=lo,ci_high=hi,valid_bootstraps=valid))
  w=counts[:,cluster]
  for outcome in ['class_switch','correct_to_incorrect','incorrect_to_correct']:
   e=g[outcome].to_numpy().astype(bool);ne=~e
   n1=e.sum();n0=ne.sum()
   den1=w[:,e].sum(axis=1);den0=w[:,ne].sum(axis=1)
   m1=np.divide(w[:,e]@x[e],den1,out=np.full(B,np.nan),where=den1>0)
   m0=np.divide(w[:,ne]@x[ne],den0,out=np.full(B,np.nan),where=den0>0)
   lo,hi,valid=ci(m1-m0)
   events.append(dict(sensitivity=sensitivity,condition=key[0],comparison=key[1],method=key[2],outcome=outcome,event_records=n1,event_images=g.loc[e,'image_id'].nunique(),nonevent_records=n0,mean_edi_event=x[e].mean() if n1 else np.nan,mean_edi_nonevent=x[ne].mean() if n0 else np.nan,mean_difference=x[e].mean()-x[ne].mean() if n1 and n0 else np.nan,ci_low=lo,ci_high=hi,valid_bootstraps=valid))
a=pd.DataFrame(rows);a.to_csv(ROOT/'probability_change_associations.csv',index=False)
pd.DataFrame(events).to_csv(ROOT/'prediction_transition_contrasts.csv',index=False)
d.drop_duplicates(['pair_id','image_id']).groupby(['condition','comparison','seed']).agg(n=('image_id','size'),class_switches=('class_switch','sum'),correct_to_incorrect=('correct_to_incorrect','sum'),incorrect_to_correct=('incorrect_to_correct','sum'),mean_absolute_probability_change=('absolute_probability_change','mean')).to_csv(ROOT/'prediction_outcome_counts.csv')
meta=dict(source_zip_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),bootstrap_reps=B,seed=SEED,cluster='image_id',stratification='true binary label; 20 images per class',seeds='fixed evaluated seeds; not resampled',threshold=.5,scope='exploratory associations; no clinical threshold; no added-value claim; no multiplicity-adjusted confirmatory tests',source_maps_and_models='not fully available in this bundle; no fresh inference or original-map numerical reproduction',formula_max_error=float(np.abs(d.edi_primary-((1-(d.pearson_corr+1)/2)+(1-d.ssim))/2).max()))
(ROOT/'analysis_metadata.json').write_text(json.dumps(meta,indent=2))
print(a[a.sensitivity.eq('all_records')].to_string(index=False))
print('fallback excluded',d.fallback_involved.sum())
