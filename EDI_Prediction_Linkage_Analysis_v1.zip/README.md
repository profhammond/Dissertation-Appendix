# EDI–prediction linkage analysis v1

This exploratory secondary analysis uses the uploaded model–input factorial bundle. It does not modify the original records, generate maps, run inference, or retrain models.

## Verified record structure

960 unique prediction records, 2,400 unique comparison records, 40 images (20 per true class), two preprocessing conditions, three fixed seeds, five comparison types, and two attribution methods. Both prediction endpoints link for every comparison using condition, seed, cell, and image identity. Comparison-plan metadata agrees exactly. Primary EDI recalculation maximum error is 2.22e-16. These checks establish recorded-data consistency, not original model or map identity.

## Analysis specification

The continuous outcome is absolute change in recorded melanoma probability. Spearman associations are estimated separately for each condition, comparison type, and method. Percentile 95% intervals use 5,000 shared image-cluster bootstrap samples, stratified by true label to preserve the sampled 20/20 balance; all evaluated seed observations for each selected image are retained. Seeds are fixed, not sampled from a population of training runs. Thus uncertainty is conditional on these models and the balanced cohort. Fallback exclusion retains only comparisons with neither endpoint marked as signed fallback (358 of 2,400 rows removed). The sparse binary contrasts compare mean EDI for an event versus no event, not deterioration versus improvement directly.

## Findings

All 20 full-record probability-change association intervals include zero. Point estimates range from -0.240 to 0.147. All 20 fallback-exclusion intervals also include zero. These observations provide no clear evidence of a monotonic relationship in this pilot; they do not establish equivalence, independence, or absence of nonlinear relationships.

Class switches occur in zero to four of the 40 images per seed and comparison setting. Event-specific support is sparse across the pooled seed records. Transition contrasts and their finite-bootstrap intervals are archived for transparency but are descriptive only when fewer than five distinct event images are available. Samples containing no events cannot estimate these contrasts; valid bootstrap counts are explicitly reported. Do not interpret nominal interval exclusion as confirmatory evidence. No multiplicity-adjusted tests, diagnostic EDI threshold, clinical validation, or incremental predictive-value result is claimed.

## Provenance and limits

The ZIP provides newly crossed map arrays and diagnostics, while original source maps and model weight hashes are not available here for full verification. This analysis recalculates EDI from recorded Pearson and SSIM values; it does not reproduce all metrics from original maps. Predicted classes agree with a 0.5 cutoff in the saved records. The model probabilities are interpreted as melanoma probabilities according to the study description; output-class encoding should be checked against the producer before manuscript integration. Forty images limit precision and event support. The balanced sampling does not estimate clinical event prevalence.

## Dissertation implication

EDI should not currently be described as an established predictor of probability changes or classification failure. A defensible statement is that the evaluated attribution disagreement did not show a clear monotonic relationship with probability changes in this small factorial cohort. The analysis adds a measured boundary to EDI interpretation; it does not establish added value beyond prediction information.

## Reproduction

Run `python analyze.py /absolute/path/to/source_bundle.zip` with Python, numpy, pandas, and scipy. No parquet engine is required: all 30 pair-part CSV files are used. The linked records, associations, transition contrasts, per-seed event counts, source ZIP SHA256, bootstrap settings, and checksum inventory accompany this report. Original inputs remain external and unchanged.
