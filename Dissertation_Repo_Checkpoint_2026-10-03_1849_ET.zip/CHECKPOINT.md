# Dissertation audit checkpoint — October 3, 2026, 18:49 ET

This checkpoint supersedes earlier status summaries for the findings below. It is prepared for https://github.com/profhammond/Dissertation-Appendix. It has NOT been committed or published by the assistant. Preserve existing repository audits. The older issue register included here is historical and predates today's findings.

## Resume here

The next task is to review the compact ZIP from **EDI_Historical_Generic_IG_Baseline_Test_v1.ipynb** after the user runs it in CPU Colab. The notebook has passed syntax checks but has not been executed against Drive by the assistant. It tests one historically evidenced generic HAM r160 baseline template against 960 frozen internal IG rows, using two protocols separately. It does not generate maps or train models. Report missing maps and configuration mismatches. A numerical match is not proof of model identity or historical execution.

Do not rerun completed pilots or audits. Do not alter original models, maps, manifests, or canonical tables. Do not sum matches across protocols as independent observations. Do not choose a baseline or protocol because it matches the target. User prefers sequential tasks, CPU mini notebooks, and copy/paste dissertation revisions. Files with x/X prefixes are old but are not authorized for deletion. No direct Drive, Overleaf, or GitHub access has been established in this conversation.

## Current reference identity

The locally retained dissertation reference is paper_analysis_manifest_balanced_six_methods.csv: 51,840 rows, 23 columns, nine configurations, SHA256 **a1c5e55f7ab4935076dad87c77ad45f0f767978cb1583631a279326d12b5cd7c**. Each configuration has 5,760 rows. The current Drive file at the same named path was found to contain 46,080 rows with SHA256 **d398b96385dd9081a536ee822b9c303f516d6e1af8ec8ab2d69aaea5b03a8722**. That version includes SIPaKMeD and excludes train_ham_test_isic; it is not the earlier manuscript eight-configuration subset. Never silently substitute it for the frozen reference.

Latest dissertation source reviewed: HAMMOND_DISSERTATION (12).zip. Its main document specifies March 2027 and Department of Computer Science; older conversational memory is not authoritative. Only chapters 1–7 are included; appendix includes are commented out. Q is supporting material proposed for the repository, with no new Appendix A currently required. A Q repository package was prepared, not published. User reports audits have been saved to GitHub; repository contents have not been independently verified.

## Critical attribution findings

1. The 7,680 Grad-CAM/Grad-CAM++ numerical reproductions remain separate from the unresolved remaining-method provenance work. The internal corpus has 23,040 rows; do not describe all methods as fully numerically reproduced.
2. Completed recorded-pair protocol v3 inspected 15,360 remaining-method rows, two attempts per row, with all 30,720 attempts calculated. Each protocol matched 9,600 complete triples against its **pair-ledger targets**: IG 3,840, SHAP 3,840, Eigen-CAM 960, Score-CAM 960. Both protocols had identical match labels. Of the matching rows, 7,200 had baseline experiment/configuration mismatch. The 5,760 Eigen/Score rows at r128/r160/r192 had missing ledger target triples, not established numerical failures.
3. Reconciliation of those saved computed values with the **frozen dissertation targets** gave adaptive matches for only 3,840 rows: Eigen-CAM 1,920 and Score-CAM 1,920, at r128/r192. Legacy matched zero; IG and SHAP matched zero under both. This is a comparison of saved audit values, not a fresh local map recomputation. The target distinction is essential.
4. Metric-export trace found exact equality for all 15,360 frozen remaining-method triples in AttributionManifest_P5P6Analysis.csv, AttributionManifest_P5P6.csv, and several AllMethods/AllAvailable exports. Both manifest files have SHA256 **bf0e0f606b7f1000a39d852a9f49d52ede981faf9528cf1758fa16bfdc1a316b**. Export consistency does not prove raw-map reproduction.
5. Frozen source path trace found both baseline_heatmap_npy and comparison_heatmap_npy equal the paths used in recorded-pair v3 for all 15,360 rows, with all referenced files present and no path errors. The 61,440 reference entries are duplicates across two sources and two map roles, not 61,440 unique maps. The discrepancy cannot be explained simply as different recorded paths in these reviewed sources.
6. Missing_heatmap_NB (3).ipynb provides direct evidence of path patching without metric recomputation. Cell 38 retained output records 40 method-specific IG HAM r160 baseline maps generated for 960 rows; cell 39 patches those baseline paths without recomputing Pearson, SSIM, or EDI. Cell 35 similarly patches SHAP comparison paths. Cell 19 records zero generated and 320 existing skipped; do not describe those as freshly generated. These observations support a metric/path disconnect hypothesis, not a proven explanation for every discrepant row.
7. The documented earlier generic example is edi_exports/heatmaps/ham_baseline_r160_20260515_045725/ISIC_0027358_heatmap.npy. The pending notebook tests this template using original recorded comparison paths and embedded verified frozen targets. Missing candidates remain unresolved.

## Training and preprocessing findings

- Saved model audit inspected 112 internal .keras files: every inspected classifier head has two softmax units. 109 stored categorical cross-entropy compile configurations; three lacked stored compile loss. Historical single-sigmoid/7-class notebook descriptions cannot describe all current saved models.
- All 112 experiment_config.json records specify two classes, 20 head / 10 fine-tuning epoch caps, learning rates .001/.00001, batch 32, seed 42. This establishes recorded configuration, not the number of executed epochs. No histories were recovered in that audit's scope.
- Recovered two-class training code includes random horizontal flipping for training, while validation/test omit it. Configurations do not explicitly record augmentation, and notebook implementations differ. The dissertation's blanket no-augmentation claim requires revision; a proposed replacement paragraph is in the reproducibility review/context and has not been confirmed applied.
- HAM diffusion execution evidence specifically links retained outputs to ham_diffusion_r224_20260519_193809. Recovered pipeline code uses batch 8 and shuffle 512, with no flip or call to apply_preprocessing; saved config says batch 32. Retained output logs 15 head and six fine-tuning epochs, versus caps 20/10. A TV diffusion function exists but no transformation call was found elsewhere in the inspected 81-cell notebook. This is an unresolved implementation/execution discrepancy, not definitive proof that saved weights received no diffusion, and it must not be generalized to all resolutions. Input-path/transformation lineage remains to be verified.

## Dissertation implications and open work

Keep attribution similarity descriptive. Lower EDI does not establish better classification, correct explanation, clinical utility, or an isolated causal preprocessing effect. Model optimization, augmentation, preprocessing, and other implementation differences can contribute.

Open items: pending generic IG test; establish metric/map historical lineage for remaining methods; verify model identities and configuration-correct baselines; resolve HAM diffusion input preprocessing; apply/confirm Chapter 3 augmentation and provenance qualifications; confirm replaced figure bytes in newest dissertation source; review remaining Appendix P selection ledger if still needed; update full table/figure register after unresolved evidence is adjudicated; compile and inspect final dissertation after edits. Do not change dissertation results solely because a new candidate protocol produces different values.

Earlier numerical/table/figure audits were completed for Chapter 4 aggregation and bootstrap; Chapter 5 frozen formula/table/figure sources; component sensitivity, latent signatures, and rankings; factorial, matched-initialization, architecture, faithfulness/localization, fixed-model controls, and V5 construct validation. These support their audited saved exports/calculations, not universal raw-map or model identity verification. The included historical register and review documents preserve details; current findings above take precedence where they differ.

## Uploads to bring into a new conversation

Upload this checkpoint ZIP first. Then upload the pending generic IG compact bundle when available and the latest dissertation ZIP if edits have occurred. For deeper source analysis, also provide the Missing_heatmap notebook and relevant raw producer notebook or original compact audit bundles. Evidence IDs and bundle names are listed in evidence_index.json. Do not rely on conversation memory for file contents.

## Repository installation

Extract this ZIP and copy its contents into a NEW repository folder such as checkpoints/2026-10-03_1849_ET/. Do not replace existing audits. Read CHECKPOINT.md first; notebooks are under notebooks/, reviewed result tables under evidence/, historical status under historical/. SHA256SUMS.json lists all packaged files except itself. Run python verify_checkpoint.py from this folder to check them. No private datasets, model weights, or heatmap arrays are included; evidence tables may contain image IDs and historical Drive paths.
