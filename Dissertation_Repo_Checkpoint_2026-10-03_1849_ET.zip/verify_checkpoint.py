from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent
d=json.loads((r/'SHA256SUMS.json').read_text())
for name,expected in d.items():
 p=r/name
 assert p.is_file(),name
 assert hashlib.sha256(p.read_bytes()).hexdigest()==expected,name
print(f'{len(d)} checkpoint files verified')
